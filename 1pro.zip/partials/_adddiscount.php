<?php
$EnterData=$_POST['discount'];
class AddDiscount{
    public $discountAmount;
    public $productAmount;
    public $percentage;

    function Addingdiscount($EnterData){

        if(strpos($EnterData,"%")==true){
            echo "yes it founded the word it works";
            
        }else{
            echo "not found";
    }
}
}

$obj= new AddDiscount();
$obj->Addingdiscount($EnterData);


?>
