<?php
$server="localhost";
$username="root";
$password="";
$database="shoppy";

$con=mysqli_connect($server,$username,$password,$database);



?>