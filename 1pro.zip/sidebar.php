<?php
session_start();

?>



<div class="body">
    <div class="nvbar">
        <div class="logo">
            <i class='bx bxs-shopping-bag-alt'></i><span>Shoppy <span class="closetop"
                    onclick="openNav()">&Cross;</span></span>
        </div>
        <div class="nvcontent">
            <ul> <?php
                if(isset($_SESSION['loggedin'])){
                    if($_SESSION['useremail']=='owner@1' or $_SESSION['userid']==15){
                        echo '<a href="/shoppyproject/controlpanel.php">
                        <li><i class="bx bxs-box"></i>Dashboard</li>
                    </a>';
                    }
               }
                ?>
                <a href="/shoppyproject/index.php">
                    <li><i class='bx bxs-home'></i> Home</li>
                </a>
                <a href="/shoppyproject/products.php">
                    <li><i class='bx bxl-product-hunt'></i> Products</li>
                </a>
                <a href="/shoppyproject/contact.php">
                    <li><i class='bx bxs-chat'></i>Message us</li>
                </a>
                <a href="/shoppyproject/orders.php">
                    <li><i class='bx bx-copy-alt'></i>My orders</li>
                </a>
               
                <a href="/shoppyproject/cart.php">
                    <li><i class='bx bxs-cart'></i>Cart</li>
                </a>
               
                <?php  
                  if(isset($_SESSION['loggedin'])){
                       echo '<a href="/shoppyproject/logout.php">
                       <li><i class="bx bx-log-out"></i> logout</li>
                   </a>';
                  }
                  else{
                     echo ' <a id="modopen" >
                     <li><i class="bx bx-log-in"></i>Signin</li>
                 </a>';
                }
                ?>
                
                <a onclick="openNav()">
                    <li id="closeside"><i class='bx bx-window-close '></i>close</li>
                </a>
            </ul>
        </div>
    </div>
</div>
<div class="containerbody">
    <div class="badycontent">
        <div class="topbar">
            <div class="logotop">
                <div class="openbtn" id="opennav" onclick="openNav()">
                    <i class='bx bx-menu'></i>
                </div>
                <div class="headmain">Shoppy</div>
                <div class="searchlap"> </div>
                <div class="searchhead">
                    <!-- <div class="btn-group dropleft mb-1">
                        <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown"
                            aria-haspopup="true" aria-expanded="false">
                            <i class='bx bx-search-alt'></i>
                        </button>
                        <div class="dropdown-menu">
                            <form class="form-inline my-2 my-lg-0">
                                <input class="form-control mr-sm-2" type="search" placeholder="Search"
                                    aria-label="Search">
                                <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
                            </form>
                        </div>
                    </div> -->
                </div>
                <div class="userimg"><i class='bx bxs-user-circle'></i></div>

            </div>
            <!-- <i class='bx bx-search-alt'></i> -->
        </div>
    </div>
    <div class="searchm">
      <form action="#">
        <div class="searchma">
        <input type="search" placeholder="search">
        </div>
        <div class="searchkot">
        <button type="submit"> <i class='bx bx-search-alt'></i></button>
        </div>
      </form>
      </div>

    <div class="modl" id="mymodal">
          <div class="modlcon">
            <h1>Shoppy </h1><div class="closemod" id="closem">&times;</div>
            <form action="partials/_loginhandles.php" method="POST">
                            <div class="form-group my-4 mx-2">
                                <label for="exampleInputEmail1">Email address</label>
                                <input type="email" class="form-control" id="logmail" name="logmail"
                                    aria-describedby="emailHelp" placeholder="Enter email">
                            </div>
                            <div class="form-group my-4 mx-2">
                                <label for="exampleInputPassword1">Password</label>
                                <input type="password" class="form-control" id="signInput" name="logpassword"
                                    placeholder="Password">
                            </div>
                            <div class="form-check my-4 mx-2">
                                <input type="checkbox" onclick="mypass()" class="form-check-input" id="exampleCheck1">
                                <label class="form-check-label" onclick="mypass()" for="exampleCheck1">Show
                                    Password</label>
                            </div>
                            <button type="submit" class="btn btn-primary ">Login</button>
                            <hr>
                            <a href="/shoppyproject/signup.php"><div class="btn btn-primary ">Signup</div></a>
                        </form>
          </div>
         
           
            
                  </div>
                  